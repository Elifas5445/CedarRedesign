LICENSE
http://www.gnu.org/licenses/gpl.html GNU/GPL

COPYRIGHT
Copyright (C) 2008 Jamp Mark Web Creations. All rights reserved.

AUTHOR
Virgilio Quilario Jr.

WEBSITE
http://www.jampmark.com/web-scripting/pure-html-css-slideshow.html

SUMMARY
Pure HTML/CSS slideshow source code and demo files.


FILES
images/       			- Contains sample images.
pure-html-css-slideshow.html	- The demo file with slideshow HTML/CSS source codes.

SUPPORT
http://www.jampmark.com/web-scripting/pure-html-css-slideshow.html - Overview, demo and comments.
